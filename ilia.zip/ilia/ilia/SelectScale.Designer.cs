﻿namespace ilia
{
    partial class SelectScale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.r0 = new System.Windows.Forms.RadioButton();
            this.r1 = new System.Windows.Forms.RadioButton();
            this.r2 = new System.Windows.Forms.RadioButton();
            this.r3 = new System.Windows.Forms.RadioButton();
            this.r4 = new System.Windows.Forms.RadioButton();
            this.SaveButton = new System.Windows.Forms.Button();
            this.r5 = new System.Windows.Forms.RadioButton();
            this.r6 = new System.Windows.Forms.RadioButton();
            this.r7 = new System.Windows.Forms.RadioButton();
            this.r8 = new System.Windows.Forms.RadioButton();
            this.r9 = new System.Windows.Forms.RadioButton();
            this.r10 = new System.Windows.Forms.RadioButton();
            this.r11 = new System.Windows.Forms.RadioButton();
            this.r12 = new System.Windows.Forms.RadioButton();
            this.r13 = new System.Windows.Forms.RadioButton();
            this.r14 = new System.Windows.Forms.RadioButton();
            this.HeightTextBox = new System.Windows.Forms.TextBox();
            this.WidthTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // r0
            // 
            this.r0.AutoSize = true;
            this.r0.Location = new System.Drawing.Point(12, 12);
            this.r0.Name = "r0";
            this.r0.Size = new System.Drawing.Size(72, 17);
            this.r0.TabIndex = 0;
            this.r0.TabStop = true;
            this.r0.Text = "1366x768";
            this.r0.UseVisualStyleBackColor = true;
            this.r0.Click += new System.EventHandler(this.radioButtons_Click);
            // 
            // r1
            // 
            this.r1.AutoSize = true;
            this.r1.Location = new System.Drawing.Point(13, 36);
            this.r1.Name = "r1";
            this.r1.Size = new System.Drawing.Size(72, 17);
            this.r1.TabIndex = 1;
            this.r1.TabStop = true;
            this.r1.Text = "1440x900";
            this.r1.UseVisualStyleBackColor = true;
            this.r1.Click += new System.EventHandler(this.radioButtons_Click);
            // 
            // r2
            // 
            this.r2.AutoSize = true;
            this.r2.Location = new System.Drawing.Point(13, 60);
            this.r2.Name = "r2";
            this.r2.Size = new System.Drawing.Size(72, 17);
            this.r2.TabIndex = 2;
            this.r2.TabStop = true;
            this.r2.Text = "1536x864";
            this.r2.UseVisualStyleBackColor = true;
            this.r2.Click += new System.EventHandler(this.radioButtons_Click);
            // 
            // r3
            // 
            this.r3.AutoSize = true;
            this.r3.Location = new System.Drawing.Point(13, 83);
            this.r3.Name = "r3";
            this.r3.Size = new System.Drawing.Size(72, 17);
            this.r3.TabIndex = 3;
            this.r3.TabStop = true;
            this.r3.Text = "1600x900";
            this.r3.UseVisualStyleBackColor = true;
            this.r3.Click += new System.EventHandler(this.radioButtons_Click);
            // 
            // r4
            // 
            this.r4.AutoSize = true;
            this.r4.Location = new System.Drawing.Point(13, 106);
            this.r4.Name = "r4";
            this.r4.Size = new System.Drawing.Size(78, 17);
            this.r4.TabIndex = 4;
            this.r4.TabStop = true;
            this.r4.Text = "1920x1080";
            this.r4.UseVisualStyleBackColor = true;
            this.r4.Click += new System.EventHandler(this.radioButtons_Click);
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(12, 157);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(284, 29);
            this.SaveButton.TabIndex = 3;
            this.SaveButton.Text = "Сохранить";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // r5
            // 
            this.r5.AutoSize = true;
            this.r5.Location = new System.Drawing.Point(102, 11);
            this.r5.Name = "r5";
            this.r5.Size = new System.Drawing.Size(66, 17);
            this.r5.TabIndex = 0;
            this.r5.TabStop = true;
            this.r5.Text = "640x960";
            this.r5.UseVisualStyleBackColor = true;
            this.r5.Click += new System.EventHandler(this.radioButtons_Click);
            // 
            // r6
            // 
            this.r6.AutoSize = true;
            this.r6.Location = new System.Drawing.Point(102, 34);
            this.r6.Name = "r6";
            this.r6.Size = new System.Drawing.Size(72, 17);
            this.r6.TabIndex = 1;
            this.r6.TabStop = true;
            this.r6.Text = "640x1136";
            this.r6.UseVisualStyleBackColor = true;
            this.r6.Click += new System.EventHandler(this.radioButtons_Click);
            // 
            // r7
            // 
            this.r7.AutoSize = true;
            this.r7.Location = new System.Drawing.Point(102, 57);
            this.r7.Name = "r7";
            this.r7.Size = new System.Drawing.Size(72, 17);
            this.r7.TabIndex = 2;
            this.r7.TabStop = true;
            this.r7.Text = "720x1280";
            this.r7.UseVisualStyleBackColor = true;
            this.r7.Click += new System.EventHandler(this.radioButtons_Click);
            // 
            // r8
            // 
            this.r8.AutoSize = true;
            this.r8.Location = new System.Drawing.Point(102, 80);
            this.r8.Name = "r8";
            this.r8.Size = new System.Drawing.Size(72, 17);
            this.r8.TabIndex = 3;
            this.r8.TabStop = true;
            this.r8.Text = "800x1280";
            this.r8.UseVisualStyleBackColor = true;
            this.r8.Click += new System.EventHandler(this.radioButtons_Click);
            // 
            // r9
            // 
            this.r9.AutoSize = true;
            this.r9.Location = new System.Drawing.Point(102, 103);
            this.r9.Name = "r9";
            this.r9.Size = new System.Drawing.Size(78, 17);
            this.r9.TabIndex = 4;
            this.r9.TabStop = true;
            this.r9.Text = "1080x1920";
            this.r9.UseVisualStyleBackColor = true;
            this.r9.Click += new System.EventHandler(this.radioButtons_Click);
            // 
            // r10
            // 
            this.r10.AutoSize = true;
            this.r10.Location = new System.Drawing.Point(102, 126);
            this.r10.Name = "r10";
            this.r10.Size = new System.Drawing.Size(78, 17);
            this.r10.TabIndex = 5;
            this.r10.TabStop = true;
            this.r10.Text = "1440x2560";
            this.r10.UseVisualStyleBackColor = true;
            this.r10.Click += new System.EventHandler(this.radioButtons_Click);
            // 
            // r11
            // 
            this.r11.AutoSize = true;
            this.r11.Location = new System.Drawing.Point(197, 11);
            this.r11.Name = "r11";
            this.r11.Size = new System.Drawing.Size(72, 17);
            this.r11.TabIndex = 6;
            this.r11.TabStop = true;
            this.r11.Text = "1024x768";
            this.r11.UseVisualStyleBackColor = true;
            this.r11.Click += new System.EventHandler(this.radioButtons_Click);
            // 
            // r12
            // 
            this.r12.AutoSize = true;
            this.r12.Location = new System.Drawing.Point(197, 34);
            this.r12.Name = "r12";
            this.r12.Size = new System.Drawing.Size(78, 17);
            this.r12.TabIndex = 7;
            this.r12.TabStop = true;
            this.r12.Text = "2048x1536";
            this.r12.UseVisualStyleBackColor = true;
            this.r12.Click += new System.EventHandler(this.radioButtons_Click);
            // 
            // r13
            // 
            this.r13.AutoSize = true;
            this.r13.Location = new System.Drawing.Point(197, 57);
            this.r13.Name = "r13";
            this.r13.Size = new System.Drawing.Size(78, 17);
            this.r13.TabIndex = 8;
            this.r13.TabStop = true;
            this.r13.Text = "2732x2048";
            this.r13.UseVisualStyleBackColor = true;
            this.r13.Click += new System.EventHandler(this.radioButtons_Click);
            // 
            // r14
            // 
            this.r14.AutoSize = true;
            this.r14.Location = new System.Drawing.Point(198, 80);
            this.r14.Name = "r14";
            this.r14.Size = new System.Drawing.Size(97, 17);
            this.r14.TabIndex = 9;
            this.r14.TabStop = true;
            this.r14.Text = "Свое разреш.:";
            this.r14.UseVisualStyleBackColor = true;
            this.r14.CheckedChanged += new System.EventHandler(this.r14_CheckedChanged);
            this.r14.Click += new System.EventHandler(this.radioButtons_Click);
            // 
            // HeightTextBox
            // 
            this.HeightTextBox.Location = new System.Drawing.Point(197, 131);
            this.HeightTextBox.Name = "HeightTextBox";
            this.HeightTextBox.Size = new System.Drawing.Size(98, 20);
            this.HeightTextBox.TabIndex = 10;
            // 
            // WidthTextBox
            // 
            this.WidthTextBox.Location = new System.Drawing.Point(198, 105);
            this.WidthTextBox.Name = "WidthTextBox";
            this.WidthTextBox.Size = new System.Drawing.Size(97, 20);
            this.WidthTextBox.TabIndex = 11;
            // 
            // SelectScale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(309, 195);
            this.Controls.Add(this.r13);
            this.Controls.Add(this.r10);
            this.Controls.Add(this.r12);
            this.Controls.Add(this.r4);
            this.Controls.Add(this.r11);
            this.Controls.Add(this.r9);
            this.Controls.Add(this.r3);
            this.Controls.Add(this.r8);
            this.Controls.Add(this.WidthTextBox);
            this.Controls.Add(this.r7);
            this.Controls.Add(this.r2);
            this.Controls.Add(this.r6);
            this.Controls.Add(this.HeightTextBox);
            this.Controls.Add(this.r5);
            this.Controls.Add(this.r1);
            this.Controls.Add(this.r14);
            this.Controls.Add(this.r0);
            this.Controls.Add(this.SaveButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "SelectScale";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Выбрать разрешение:";
            this.Load += new System.EventHandler(this.SelectScale_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton r0;
        private System.Windows.Forms.RadioButton r4;
        private System.Windows.Forms.RadioButton r3;
        private System.Windows.Forms.RadioButton r2;
        private System.Windows.Forms.RadioButton r1;
        private System.Windows.Forms.RadioButton r10;
        private System.Windows.Forms.RadioButton r9;
        private System.Windows.Forms.RadioButton r8;
        private System.Windows.Forms.RadioButton r7;
        private System.Windows.Forms.RadioButton r6;
        private System.Windows.Forms.RadioButton r5;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.RadioButton r13;
        private System.Windows.Forms.RadioButton r12;
        private System.Windows.Forms.RadioButton r11;
        private System.Windows.Forms.RadioButton r14;
        private System.Windows.Forms.TextBox HeightTextBox;
        private System.Windows.Forms.TextBox WidthTextBox;
    }
}